import streamlit as st
from groq import Groq
import speech_recognition as sr
import tempfile
from langchain.chains import ConversationChain, LLMChain
from langchain_core.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    MessagesPlaceholder,
)
from langchain_core.messages import SystemMessage
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate


def main():
    # Get Groq API key
    groq_api_key = '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'  # Replace 'your_api' with your actual API key

    # The title and greeting message of the Streamlit application
    prep = st.session_state.resume_details
    prep += ' ............... Conduct a mock interview based on the resume details provided, ask ten questions one by one and evaluate the performance at the end of all ten questions'

    model = 'llama3-8b-8192'
    conversational_memory_length = 10

    memory = ConversationBufferWindowMemory(k=conversational_memory_length, memory_key="chat_history", return_messages=True)

    # Initialize Groq Langchain chat object and conversation
    groq_chat = ChatGroq(
        groq_api_key=groq_api_key,
        model_name=model
    )

    prompt = ChatPromptTemplate.from_messages(
        [
            SystemMessage(content=prep),  # This is the persistent system prompt that is always included at the start of the chat.
            MessagesPlaceholder(variable_name="chat_history"),  # This placeholder will be replaced by the actual chat history during the conversation. It helps in maintaining context.
        ]
    )
    conversation = LLMChain(
        llm=groq_chat,  # The Groq LangChain chat object initialized earlier.
        prompt=prompt,  # The constructed prompt template.
        memory=memory,  # The conversational memory object that stores and manages the conversation history.
    )
    
    # Function to record audio and convert it to text
    def record_and_transcribe():
        recognizer = sr.Recognizer()
        st.write("Click the button below and speak to convert your speech to text.")

        if st.button("Start Recording"):
            # Create a temporary file to store the recorded audio
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio_file:
                temp_audio_path = temp_audio_file.name

            # Record audio from the microphone
            with sr.Microphone() as source:
                st.write("Recording...")
                audio = recognizer.listen(source)
                st.write("Recording stopped.")

                # Save the recorded audio to the temporary file
                with open(temp_audio_path, "wb") as f:
                    f.write(audio.get_wav_data())

            # Convert the audio to text
            try:
                with sr.AudioFile(temp_audio_path) as source:
                    audio = recognizer.record(source)
                    text = recognizer.recognize_google(audio)
                    return text
            except sr.UnknownValueError:
                st.write("Google Speech Recognition could not understand audio.")
                return ""
            except sr.RequestError as e:
                st.write(f"Could not request results from Google Speech Recognition service; {e}")
                return ""
    
    # Main interview loop
    for i in range(10):
        # Get question from chatbot
        response = conversation.predict(human_input=prep)
        st.write(response)
        
        # Record and transcribe the user's answer
        user_response = record_and_transcribe()
        
        if user_response:
            st.write("You said: ", user_response)
            st.session_state.chat_history.append({'human': user_response, 'AI': response})

            # Update the conversation with the user's answer
            memory.save_context(
                {'input': user_response},
                {'output': response}
            )

            # Update prompt for the next question
            prompt = ChatPromptTemplate.from_messages(
                [
                    MessagesPlaceholder(variable_name="chat_history"),  # This placeholder will be replaced by the actual chat history during the conversation.
                    HumanMessagePromptTemplate.from_template("{human_input}"),  # This template is where the user's current input will be injected into the prompt.
                ]
            )
            conversation = LLMChain(
                llm=groq_chat,  # The Groq LangChain chat object initialized earlier.
                prompt=prompt,  # The constructed prompt template.
                memory=memory,  # The conversational memory object that stores and manages the conversation history.
            )

    # Final evaluation
    st.write("Interview completed. Evaluating performance...")
    evaluation_prompt = "Evaluate the performance based on the answers provided."
    evaluation_response = conversation.predict(human_input=evaluation_prompt)
    st.write(evaluation_response)


if __name__ == "__main__":
    main()
