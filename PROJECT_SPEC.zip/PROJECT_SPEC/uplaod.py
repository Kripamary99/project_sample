import streamlit as st
from PyPDF2 import PdfReader
import pdfplumber
from streamlit_extras.switch_page_button import switch_page

st.set_page_config(page_title='Resume Upload')
st.sidebar.success("Select page above")

def read_pdf(file):
    reader=PdfReader(file)
    count=len(reader.pages)
    all_page_text=""
    for i in range(count):
        page=reader.pages[i]
        all_page_text+=page.extract_text()
    return all_page_text


text=''
def main():
    st.title("RESUME UPLOAD") 
    file=st.file_uploader("Upload resume",type=["pdf"])
    if st.button("Process"):
        if file is not None:
            #filename=file.nameupload 
            #filesize=file.size
            #st.write(filename,filesize)
            text=read_pdf(file)
            #st.write(text)
            st.session_state.resume_details= text
            st.switch_page("pages\interview_page.py")

if __name__=='__main__':
    main()